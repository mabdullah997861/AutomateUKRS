AutomateUKRS
=====================

Page Object Framework using cucumber jvm (java) and Selenium java.
